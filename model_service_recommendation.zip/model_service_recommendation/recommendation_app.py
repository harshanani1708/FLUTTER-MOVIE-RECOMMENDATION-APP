from flask import Flask, request, jsonify
import traceback
import joblib
import pandas as pd
import numpy as np

app = Flask(__name__)
'''lr = joblib.load('model.pkl')'''

@app.route("/")
def hello():
    return "Welcome to machine learning model APIs!"

@app.route("/top",methods=['GET'])
def top_movies():  
	return top_movies_model['title'][:10].to_json()

@app.route("/content_recommendation",methods=['POST'])
def content_base_recommendation():

    json_data= request.json
 
    title = json_data["movie"]

    
    ##MODEL DEPLOYMENT

    indices = pd.Series(df2.index, index=df2['title']).drop_duplicates()
    idx = indices[title]

    # Get the pairwsie similarity scores of all movies with that movie
    sim_scores = list(enumerate(cosine_sim[idx]))

    # Sort the movies based on the similarity scores
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

    # Get the scores of the 10 most similar movies
    sim_scores = sim_scores[1:5]

    # Get the movie indices
    movie_indices = [i[0] for i in sim_scores]
    # Return the top 10 most similar movies
    predictionsData = list(df2['title'].iloc[movie_indices])
    return jsonify({'predictionmovies':predictionsData})

@app.route("/getmovies",methods=['GET'])
def get_movies():
    data = list(df2['title'][500:1000])
    #datamovieoverview = list(df2['overview'][3000:3100])
    return jsonify({"movies":data})
	

if __name__ == '__main__':
	
    top_movies_model = joblib.load("qmovies_model.pkl") # Load "model.pkl"
    print ('Model loaded')
    #model_columns = joblib.load("model_columns.pkl") # Load "model_columns.pkl"
    #print ('Model columns loaded')
    cosine_sim = joblib.load("content_based_model_final.pkl")
    print("Content based model")
        ##Loading the  data
    df1 = pd.read_csv('tmdb_5000_credits.csv')
    df2 = pd.read_csv("tmdb_5000_movies.csv")

    df1.columns = ['id','tittle','cast','crew'] 
    df2=df2.merge(df1,on='id')

    app.run(port=12345,debug=True)